package com.wallet.transaction.service;

import java.util.List;

import com.wallet.transaction.entity.Users;
public interface UserServiceDeepika {
   List<Users> getAllUsers();
   
//   Users getUserByName(String name);
   
}