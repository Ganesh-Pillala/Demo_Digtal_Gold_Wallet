package com.cg.task.db.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.task.db.entity.Employee;
import com.cg.task.db.entity.Location;
import com.cg.task.db.repo.EmployeeRepository;
import com.cg.task.db.repo.LocationRepository;

@RestController
@RequestMapping("/api/locationsSatya")
public class LocationControllerSatya {

    @Autowired
    private LocationRepository locationRepository;

    @Autowired
    private EmployeeRepository employeeRepo;

    @GetMapping
    public List<Location> getAllLocations() {
        return locationRepository.findAll();
    }

    @GetMapping("/{locationId}/employees")
    public List<Employee> getEmployeesByLocation(@PathVariable Long locationId) {
        return employeeRepo.findByDepartment_Location_Id(locationId);
    }
}

