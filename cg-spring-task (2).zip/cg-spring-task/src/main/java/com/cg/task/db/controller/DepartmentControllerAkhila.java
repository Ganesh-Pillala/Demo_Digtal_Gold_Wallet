package com.cg.task.db.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.cg.task.db.entity.Department;
import com.cg.task.db.repo.DepartmentsRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
//
//@RestController
//@RequestMapping("/departments")
//
//
//public class DepartmentController {
//
//    @Autowired
//    private DepartmentRepository departmentRepository;
//
//    @GetMapping
//    public String departments(Model model) {
//        model.addAttribute("departments", departmentRepository.findAll());
//        return "departments";
//    }
//
//    @GetMapping("/{id}")
//    public String findById(@PathVariable("id") Long id, Model model) {
//        Optional<Department> department = departmentRepository.findById(id);
//        model.addAttribute("department", department.orElse(null));
//        return "department-detail";
//    }
//
//    @GetMapping("/search")
//    public String findByName(@RequestParam("name") String name, Model model) {
//        model.addAttribute("departments", departmentRepository.findByDepartmentNameContainingIgnoreCase(name));
//        return "departments";
//    }
//}
//
//
@RestController
@RequestMapping("/departments")
@Tag(name = "Department API", description = "Operations related to departments")
public class DepartmentControllerAkhila {

    @Autowired
    private DepartmentsRepository departmentRepository;

    @GetMapping
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Department> getDepartmentById(@PathVariable("id") BigDecimal id) {
        return departmentRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }


    @GetMapping("/search")
    public List<Department> searchDepartments(@RequestParam("name") String name) {
        return departmentRepository.findByDepartmentNameContainingIgnoreCase(name);
    }
}