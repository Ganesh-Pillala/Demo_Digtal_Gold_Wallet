package com.cg.task.db.repo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.task.db.entity.Department;

public interface DepartmentsRepository extends JpaRepository<Department, BigDecimal> {
	List<Department> findByDepartmentNameContainingIgnoreCase(String name);
	List<Department> findByLocation_Id(Long locationId);
}