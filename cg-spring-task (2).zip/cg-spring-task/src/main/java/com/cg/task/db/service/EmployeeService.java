package com.cg.task.db.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.task.db.entity.Employee;
@Service
public interface EmployeeService {
    List<Employee> getAllEmployees();
 
}