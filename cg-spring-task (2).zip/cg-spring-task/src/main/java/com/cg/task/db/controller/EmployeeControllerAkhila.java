package com.cg.task.db.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.task.db.entity.Employee;
import com.cg.task.db.repo.EmployeeRepository;

import io.swagger.v3.oas.annotations.tags.Tag;

//
//@RestController
//@RequestMapping("/api/employees")
//@Tag(name = "Employee API", description = "Operations related to employees")
//
//public class EmployeeController {
//
//    @Autowired
//    private EmployeeRepository employeeRepository;
//
//    @GetMapping
//    public String employees(Model model) {
//        model.addAttribute("employees", employeeRepository.findAll());
//        return "employees";
//    }
//
//    @GetMapping("/{id}")
//    public String findById(@PathVariable("id") Long id, Model model) {
//        Optional<Employee> employee = employeeRepository.findById(id);
//        model.addAttribute("employee", employee.orElse(null));
//        return "employee-detail";
//    }
//
//    @GetMapping("/search")
//    public String findByName(@RequestParam("name") String name, Model model) {
//        model.addAttribute("employees", employeeRepository.findByFirstNameContainingIgnoreCase(name));
//        return "employees";
//    }
//}
//
@RestController
@RequestMapping("/api/employees")
@Tag(name = "Employee API", description = "Operations related to employees")
public class EmployeeControllerAkhila {

    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable("id") Long id) {
        return employeeRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/search")
    public List<Employee> searchEmployees(@RequestParam("name") String name) {
        return employeeRepository.findByFirstNameContainingIgnoreCase(name);
    }
}