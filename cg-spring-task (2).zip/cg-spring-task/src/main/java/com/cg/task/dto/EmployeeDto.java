package com.cg.task.dto;


import java.time.LocalDate;


public class EmployeeDto {
    private Long employeeId;
    private String fullName;
    private String email;
    private String phoneNumber;
    private LocalDate hireDate;

//    public EmployeeDto(Long employeeId, String fullName, String email, String phoneNumber, LocalDate hireDate) {
//        this.employeeId = employeeId;
//        this.fullName = fullName;
//        this.email = email;
//        this.phoneNumber = phoneNumber;
//        this.hireDate = hireDate;
//    }
    
    public EmployeeDto(Long employeeId, String fullName, String email, String phoneNumber, LocalDate hireDate) {
        this.employeeId = employeeId;
        this.fullName = fullName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.hireDate = hireDate;
    }


    // Getters and Setters
    public Long getEmployeeId() { return employeeId; }
    public void setEmployeeId(Long employeeId) { this.employeeId = employeeId; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public LocalDate getHireDate() { return hireDate; }
    public void setHireDate(LocalDate hireDate) { this.hireDate = hireDate; }
}