package com.cg.task.db.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.List;
 
import com.fasterxml.jackson.annotation.JsonIgnore;
 
@Entity
@Table(name = "jobs")
public class Job {
 
    @Id
    @Column(name = "job_id")
    private String jobId;
 
    @Column(name = "job_title")
    private String jobTitle;
 
    @Column(name = "min_salary")
    private BigDecimal minSalary;
 
    @Column(name = "max_salary")
    private BigDecimal maxSalary;
 
    @OneToMany(mappedBy = "job", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Employee> employees;
 
    // Constructors
    public Job() {}
 
    public Job(String jobId, String jobTitle, BigDecimal minSalary, BigDecimal maxSalary) {
        this.jobId = jobId;
        this.jobTitle = jobTitle;
        this.minSalary = minSalary;
        this.maxSalary = maxSalary;
    }
 
    // Getters and Setters
    public String getJobId() {
        return jobId;
    }
 
    public void setJobId(String jobId) {
        this.jobId = jobId;
    }
 
    public String getJobTitle() {
        return jobTitle;
    }
 
    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }
 
    public BigDecimal getMinSalary() {
        return minSalary;
    }
 
    public void setMinSalary(BigDecimal minSalary) {
        this.minSalary = minSalary;
    }
 
    public BigDecimal getMaxSalary() {
        return maxSalary;
    }
 
    public void setMaxSalary(BigDecimal maxSalary) {
        this.maxSalary = maxSalary;
    }
 
    public List<Employee> getEmployees() {
        return employees;
    }
 
    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }
}