package com.cg.task.dto;

import java.time.LocalDate;

public class JobHistoryDto {
    private String employeeFullName;
    private LocalDate startDate;
    private LocalDate endDate;
    private String jobTitle;

    public JobHistoryDto(String employeeFullName, LocalDate startDate, LocalDate endDate, String jobTitle) {
        this.employeeFullName = employeeFullName;
        this.startDate = startDate;
        this.endDate = endDate;
        this.jobTitle = jobTitle;
    }

    // Getters and Setters
    public String getEmployeeFullName() { return employeeFullName; }
    public void setEmployeeFullName(String employeeFullName) { this.employeeFullName = employeeFullName; }

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }

    public String getJobTitle() { return jobTitle; }
    public void setJobTitle(String jobTitle) { this.jobTitle = jobTitle; }
}