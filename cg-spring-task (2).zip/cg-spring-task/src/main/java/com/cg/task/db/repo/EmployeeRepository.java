package com.cg.task.db.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.task.db.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
	List<Employee> findByFirstNameContainingIgnoreCase(String name);
	List<Employee> findByJob_JobId(String jobId);
	List<Employee> findByDepartment_Location_Id(Long locationId);
}


