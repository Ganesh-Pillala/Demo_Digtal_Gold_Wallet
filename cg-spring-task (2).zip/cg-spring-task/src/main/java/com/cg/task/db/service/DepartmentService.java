package com.cg.task.db.service;

import org.springframework.stereotype.Service;
import com.cg.task.db.entity.Department;
import com.cg.task.db.entity.Employee;

import com.cg.task.db.repo.EmployeeRepository;

@Service
public class DepartmentService {

    private final EmployeeRepository employeeRepository;

    public DepartmentService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public Department getDepartmentByEmployeeId(Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found with ID: " + employeeId));
        return employee.getDepartment();
    }
}