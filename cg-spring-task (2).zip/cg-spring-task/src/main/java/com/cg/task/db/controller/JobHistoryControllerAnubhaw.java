package com.cg.task.db.controller;

import org.springframework.web.bind.annotation.*;

import com.cg.task.db.entity.JobHistory;
import com.cg.task.db.service.JobHistoryServiceAnubhaw;

import java.util.List;

@RestController
@RequestMapping("/job-history")
public class JobHistoryControllerAnubhaw {

    private final JobHistoryServiceAnubhaw jobHistoryService;

    public JobHistoryControllerAnubhaw(JobHistoryServiceAnubhaw jobHistoryService) {
        this.jobHistoryService = jobHistoryService;
    }

    @GetMapping("/employee/{id}")
    public List<JobHistory> getJobHistoryByEmployeeId(@PathVariable Long id) {
        return jobHistoryService.getJobHistoryByEmployeeId(id); // ✅ Use 'id' not 'employee_id'
    }
}