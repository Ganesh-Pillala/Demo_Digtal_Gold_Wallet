package com.cg.task.db.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.task.db.entity.Employee;
import com.cg.task.db.service.EmployeeService;

import java.util.List;

@RestController
@RequestMapping("/api/getemployeesSatya")
public class EmployeeControllerSatya {

    private final EmployeeService employeeService;

    public EmployeeControllerSatya(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }
}