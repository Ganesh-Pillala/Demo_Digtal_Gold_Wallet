package com.cg.task.db.repo;


import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.task.db.entity.JobHistory;
import java.util.List;

public interface JobHistoryRepository extends JpaRepository<JobHistory, Long> {
    List<JobHistory> findByEmployee_EmployeeId(Long employeeId); // ✅ Correct method
}