package com.cg.task.db.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.task.db.entity.Employee;
import com.cg.task.db.repo.EmployeeRepository;


@Service
public class EmployeeServiceVishnu {
    private final EmployeeRepository employeeRepository;

    public EmployeeServiceVishnu(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public List<Employee> getEmployeesByJobId(String jobId) {
        return employeeRepository.findByJob_JobId(jobId);
    }
}