package com.cg.task.db.controller;

import com.cg.task.db.entity.Department;
import com.cg.task.db.service.DepartmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/departments")
public class DepartmentController {

    private final DepartmentService departmentService;

    public DepartmentController(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    @Operation(summary = "Get Department by Employee ID", description = "Fetch department details for a given employee ID")
    @GetMapping("/by-employee/{employeeId}")
    public ResponseEntity<Department> getDepartmentByEmployeeId(
            @Parameter(description = "Employee ID", example = "101")
            @PathVariable("employeeId") Long employeeId) {
        Department department = departmentService.getDepartmentByEmployeeId(employeeId);
        return ResponseEntity.ok(department);
    }
}