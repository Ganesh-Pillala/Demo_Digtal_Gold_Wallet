package com.cg.task.db.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.task.db.entity.Job;
import com.cg.task.db.repo.JobRepository;

@Service
public class JobServiceVishnu {
    private final JobRepository jobRepository;

    public JobServiceVishnu(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

    public Job getJobById(String jobId) {
        return jobRepository.findById(jobId).orElse(null);
    }
}