package com.cg.task.db.serviceimpl;


import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.task.db.entity.Employee;
import com.cg.task.db.repo.EmployeeRepository;
import com.cg.task.db.service.EmployeeService;
 
@Service

public class EmployeeServiceImpl implements EmployeeService {
 
    private final EmployeeRepository repository;
 
    public EmployeeServiceImpl(EmployeeRepository repository) {

        this.repository = repository;

    }
 
    @Override

    public List<Employee> getAllEmployees() {

        return repository.findAll(); // Return full entity list directly

    }

}
 