package com.cg.task.db.controller;

import org.springframework.web.bind.annotation.*;
import com.cg.task.db.entity.Employee;
import com.cg.task.db.service.EmployeeService;

import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeControllerAnubhaw {

    private final EmployeeService employeeService;

    public EmployeeControllerAnubhaw(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }
}