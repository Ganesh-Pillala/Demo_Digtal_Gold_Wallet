package com.cg.task.db.service;
import java.util.List;
import com.cg.task.db.entity.JobHistory;

public interface JobHistoryServiceAnubhaw {
    List<JobHistory> getJobHistoryByEmployeeId(Long employeeId);
}