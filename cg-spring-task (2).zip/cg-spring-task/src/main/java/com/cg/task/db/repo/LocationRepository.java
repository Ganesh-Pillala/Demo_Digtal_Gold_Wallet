package com.cg.task.db.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.task.db.entity.Location;

public interface LocationRepository extends JpaRepository<Location, Long> {
}
