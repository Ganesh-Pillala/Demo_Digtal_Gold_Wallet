package com.cg.task.db.serviceimpl;

import org.springframework.stereotype.Service;

import com.cg.task.db.entity.JobHistory;
import com.cg.task.db.repo.JobHistoryRepository;
import com.cg.task.db.service.JobHistoryServiceAnubhaw;

import java.util.List;

@Service 
public class JobHistoryServiceImpl implements JobHistoryServiceAnubhaw {

    private final JobHistoryRepository jobHistoryRepository;

    public JobHistoryServiceImpl(JobHistoryRepository jobHistoryRepository) {
        this.jobHistoryRepository = jobHistoryRepository;
    }

    @Override
    public List<JobHistory> getJobHistoryByEmployeeId(Long employeeId) {
        return jobHistoryRepository.findByEmployee_EmployeeId(employeeId);
    }
}