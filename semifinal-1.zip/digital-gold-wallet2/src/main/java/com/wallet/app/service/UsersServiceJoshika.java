package com.wallet.app.service;

import java.util.List;

import com.wallet.app.model.Users;

public interface UsersServiceJoshika {

List<Users> getAllUsers();



}