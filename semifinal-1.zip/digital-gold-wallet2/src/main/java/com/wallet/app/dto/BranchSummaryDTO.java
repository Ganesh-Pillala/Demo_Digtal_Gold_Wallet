package com.wallet.app.dto;

public class BranchSummaryDTO {
    private Long branchId;
    private Double quantity;

    public BranchSummaryDTO(Long branchId, Double quantity) {
        this.branchId = branchId;
        this.quantity = quantity;
    }

    public Long getBranchId() {
        return branchId;
    }

    public void setBranchId(Long branchId) {
        this.branchId = branchId;
    }

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }
}