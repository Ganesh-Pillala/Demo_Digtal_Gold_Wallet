package com.cg.film.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BranchSummaryDTO {
    private Integer branchId;
    private Integer quantity;

    @JsonProperty("branch_name")
    private String branchName; // maps snake_case -> camelCase

    public Integer getBranchId() { return branchId; }
    public void setBranchId(Integer branchId) { this.branchId = branchId; }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }

    public String getBranchName() { return branchName; }
    public void setBranchName(String branchName) { this.branchName = branchName; }
}