package com.cg.film.controller;

import com.cg.film.model.BranchSummaryDTO;
import com.cg.film.model.Vendor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Controller
public class VendorsViewController {

    private final RestTemplate restTemplate;

    @Value("${backend.base.url}")
    private String backendBaseUrl;

    public VendorsViewController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    // /vendors -> table of vendors
    @GetMapping("/vendors")
    public String vendors(Model model) {
        String url = backendBaseUrl + "/api/vendors";
        Vendor[] arr = restTemplate.getForObject(url, Vendor[].class);
        List<Vendor> vendors = (arr != null) ? Arrays.asList(arr) : List.of();
        model.addAttribute("vendors", vendors);
        return "vendors"; // templates/vendors.html
    }

    // /vendors/branch-summary -> table of branch summaries (all vendors aggregated)
    @GetMapping("/vendors/branch-summary")
    public String branchSummary(Model model) {
        String url = backendBaseUrl + "/api/vendors/branch-summary";
        BranchSummaryDTO[] arr = restTemplate.getForObject(url, BranchSummaryDTO[].class);
        List<BranchSummaryDTO> summaries = (arr != null) ? Arrays.asList(arr) : List.of();
        model.addAttribute("summaries", summaries);
        return "branch-summary"; // templates/branch-summary.html
    }
}