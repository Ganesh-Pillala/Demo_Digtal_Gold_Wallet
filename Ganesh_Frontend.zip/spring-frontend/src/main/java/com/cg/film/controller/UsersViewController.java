package com.cg.film.controller;

import com.cg.film.model.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;         // <-- Use @Controller
import org.springframework.ui.Model;                // <-- Model for view
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Controller
public class UsersViewController {

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/users")
    public String usersPage(Model model) {          // <-- Accept Model here
        String backendUrl = "http://localhost:8080/api/users";

        // Fetch array of Users from backend
        Users[] usersArray = restTemplate.getForObject(backendUrl, Users[].class);

        // Convert array to List safely
        List<Users> users = (usersArray != null) ? Arrays.asList(usersArray) : List.of();

        // Add to model for Thymeleaf
        model.addAttribute("users", users);

        // Return Thymeleaf view name -> src/main/resources/templates/users.html
        return "users";
    }
}