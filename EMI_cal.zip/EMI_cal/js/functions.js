
//==========================================================
// Person 4
// Functions Module
// JavaScript Concepts:
// Function Declaration
// Parameters
// Return Values
// Reusable Functions
//==========================================================


// Validate Age

function validateAge(age) {

    return age >= 21;

}


// Validate Income

function validateIncome(income) {

    return income >= 25000;

}


// Validate Credit Score

function validateCreditScore(score) {

    return score >= 650;

}


// Calculate EMI (Simple Formula)

function calculateEMI(amount, months) {

    return (amount / months).toFixed(2);

}


// Get Risk Level

function getRiskLevel(score) {

    if (score >= 750) {

        return "Low Risk";

    }

    else if (score >= 650) {

        return "Medium Risk";

    }

    else {

        return "High Risk";

    }

}


// Calculate Eligible Loan

function calculateEligibleLoan(amount) {

    return amount * 2;

}


// Format Currency

function formatCurrency(amount) {

    return "₹ " + Number(amount).toLocaleString("en-IN");

}


// Main Function

function runFunctions() {

    let amount =
        Number(document.getElementById("amount").value);

    let months =
        Number(document.getElementById("months").value);

    let score =
        Number(document.getElementById("score").value);


    // Validation

    if (

        amount <= 0 ||

        months <= 0 ||

        score <= 0

    ) {

        document.getElementById("output").innerHTML =

            "<h3>Please fill all fields correctly.</h3>";

        return;

    }


    // Function Calls

    let emi =
        calculateEMI(amount, months);

    let risk =
        getRiskLevel(score);

    let eligibleLoan =
        calculateEligibleLoan(amount);


    // Display Output

    document.getElementById("output").innerHTML =

        "<h3>Function Results</h3>" +

        "<p><strong>Monthly EMI :</strong> "

        + formatCurrency(Number(emi)) +

        "</p>" +

        "<p><strong>Risk Level :</strong> "

        + risk +

        "</p>" +

        "<p><strong>Eligible Loan :</strong> "

        + formatCurrency(eligibleLoan) +

        "</p>";

}
