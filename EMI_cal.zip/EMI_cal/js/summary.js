
//==========================================================
// Person 5
// Summary Module
// JavaScript Concepts:
// Object
// DOM Manipulation
// Local Storage
//==========================================================

function loadSummary() {

    // Get Applicant Data

    let loanData =
        JSON.parse(localStorage.getItem("loanApplicant"));

    if (!loanData) {

        alert("No applicant data found.");

        return;

    }

    // User Details

    document.getElementById("userName").innerText =
        loanData.name;

    document.getElementById("userAge").innerText =
        loanData.age;

    document.getElementById("userIncome").innerText =
        "₹ " + loanData.income.toLocaleString();

    document.getElementById("userEmployment").innerText =
        loanData.employment;


    // Loan Details

    document.getElementById("summaryAmount").innerText =
        "₹ " + loanData.loanAmount.toLocaleString();

    document.getElementById("summaryEmi").innerText =
        "₹ " + Number(loanData.emi).toFixed(2);

    document.getElementById("summaryInterest").innerText =
        "₹ " + Number(loanData.totalInterest).toFixed(2);


    // Status

    document.getElementById("summaryStatus").innerText =
        loanData.status;


    // Reason & Recommendation

    if (loanData.status === "Approved") {

        document.getElementById("summaryReason").innerText =
            "Applicant satisfies all loan eligibility conditions.";

        document.getElementById("summaryRecommendation").innerText =
            "Recommended to proceed with loan processing.";

    }

    else {

        document.getElementById("summaryReason").innerText =
            "Applicant does not satisfy the eligibility criteria.";

        document.getElementById("summaryRecommendation").innerText =
            "Improve income or credit score before reapplying.";

    }


    // Status Badge

    let status =
        document.getElementById("summaryStatus");

    status.classList.remove(
        "approved",
        "rejected",
        "pending"
    );

    if (loanData.status === "Approved") {

        status.classList.add("approved");

    }

    else {

        status.classList.add("rejected");

    }

}


// Load Automatically

window.onload = loadSummary;