

function loadSummary() {

    let loanData =
        JSON.parse(localStorage.getItem("loanApplicant"));

    if (!loanData) {

        alert("No applicant data found.");

        return;

    }

    //=========================
    // User Details
    //=========================

    document.getElementById("userName").innerText =
        loanData.name;

    document.getElementById("userAge").innerText =
        loanData.age;

    document.getElementById("userIncome").innerText =
        "₹ " + Number(loanData.income).toLocaleString("en-IN");

    document.getElementById("userEmployment").innerText =
        loanData.employment;


    //=========================
    // Loan Details
    //=========================

    document.getElementById("summaryAmount").innerText =
        "₹ " + Number(loanData.loanAmount).toLocaleString("en-IN");

    document.getElementById("summaryEmi").innerText =
        "₹ " + Number(loanData.emi).toFixed(2);

    document.getElementById("summaryInterest").innerText =
        "₹ " + Number(loanData.totalInterest).toFixed(2);


    //=========================
    // Decision
    //=========================

    let status =
        document.getElementById("summaryStatus");

    status.innerText =
        loanData.status;

    status.classList.remove(
        "approved",
        "rejected",
        "pending"
    );


    //=========================
    // Recommendation
    //=========================

    switch (loanData.status) {

        case "Loan Approved":

            status.classList.add("approved");

            document.getElementById("summaryReason").innerText =
                "Applicant satisfies all eligibility conditions.";

            document.getElementById("summaryRecommendation").innerText =
                "Recommended to proceed with loan processing.";

            break;


        case "Approval Pending":

            status.classList.add("pending");

            document.getElementById("summaryReason").innerText =
                "Application requires manual verification.";

            document.getElementById("summaryRecommendation").innerText =
                "Verify applicant documents before approval.";

            break;


        case "Rejected - Age Not Eligible":

            status.classList.add("rejected");

            document.getElementById("summaryReason").innerText =
                "Applicant age is outside the eligible range (21-60 years).";

            document.getElementById("summaryRecommendation").innerText =
                "Loan cannot be processed.";

            break;


        case "Rejected - Low Income":

            status.classList.add("rejected");

            document.getElementById("summaryReason").innerText =
                "Monthly income is below ₹25,000.";

            document.getElementById("summaryRecommendation").innerText =
                "Increase income before reapplying.";

            break;


        case "Rejected":

            status.classList.add("rejected");

            document.getElementById("summaryReason").innerText =
                "Credit score is below the required level.";

            document.getElementById("summaryRecommendation").innerText =
                "Improve credit score before reapplying.";

            break;


        default:

            status.classList.add("pending");

            document.getElementById("summaryReason").innerText =
                "Decision not available.";

            document.getElementById("summaryRecommendation").innerText =
                "Complete all previous modules.";

    }

}

window.onload = loadSummary;