
//==========================================================
// Person 3
// Decision Module
// JavaScript Concepts:
// if-else
// Nested if
// switch-case
// Arrays
// Loops
//==========================================================


// Employment Category

function getEmploymentCategory(type) {

    switch (type) {

        case "government":
            return "Low Risk";

        case "private":
            return "Medium Risk";

        case "business":
            return "High Risk";

        default:
            return "Unknown Category";

    }

}



// Loan Decision

function evaluateLoan(age, income, score) {

    if (validateAge(age)) {

        if (validateIncome(income)) {

            if (score >= 750) {

                return "Loan Approved";

            }

            else if (score >= 650) {

                return "Approval Pending";

            }

            else {

                return "Rejected";

            }

        }

        else {

            return "Rejected - Low Income";

        }

    }

    else {

        return "Rejected - Age Not Eligible";

    }

}



// Remarks using Array

function showRemarks(age, income, score) {

    let remarks = [];

    if (age >= 21) {

        remarks.push("✓ Age Criteria Passed");

    }

    else {

        remarks.push("✗ Age Criteria Failed");

    }

    if (income >= 25000) {

        remarks.push("✓ Income Verified");

    }

    else {

        remarks.push("✗ Income Below Requirement");

    }

    if (score >= 650) {

        remarks.push("✓ Good Credit Score");

    }

    else {

        remarks.push("✗ Poor Credit Score");

    }


    let output = "";


    // Loop Example

    for (let i = 0; i < remarks.length; i++) {

        output += remarks[i] + "<br>";

    }


    document.getElementById("remarks").innerHTML = output;

}



// Main Function

function checkDecision() {

    let age =
        Number(document.getElementById("age").value);

    let income =
        Number(document.getElementById("income").value);

    let score =
        Number(document.getElementById("score").value);

    let employment =
        document.getElementById("employment").value;



    // Validation

    if (

        age === 0 ||

        income === 0 ||

        score === 0 ||

        employment === ""

    ) {

        document.getElementById("result").innerHTML =
            "Please fill all fields.";

        document.getElementById("remarks").innerHTML = "";

        return;

    }


    let category =
        getEmploymentCategory(employment);


    let status =
        evaluateLoan(age, income, score);


    // Object Example

    let applicant = {

        age,

        income,

        score,

        category,

        status

    };


    document.getElementById("result").innerHTML =

        "<h3>" + applicant.status + "</h3>" +

        "<p><strong>Risk Level :</strong> "

        + applicant.category +

        "</p>";


    showRemarks(

        age,

        income,

        score

    );

}