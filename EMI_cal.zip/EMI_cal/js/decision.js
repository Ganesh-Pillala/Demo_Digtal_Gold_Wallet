

window.onload = function () {

    let loanData =
        JSON.parse(localStorage.getItem("loanApplicant"));

    if (!loanData) return;

    document.getElementById("age").value =
        loanData.age;

    document.getElementById("income").value =
        loanData.income;

    document.getElementById("score").value =
        loanData.creditScore;

    document.getElementById("employment").value =
        loanData.employment;

};


// Employment Category

function getEmploymentCategory(type) {

    switch (type) {

        case "government":
            return "Low Risk";

        case "private":
            return "Medium Risk";

        case "business":
            return "High Risk";

        default:
            return "Unknown Category";

    }

}


// Loan Decision

function evaluateLoan(age, income, score) {

    if (age < 21 || age > 60) {

        return "Rejected - Age Not Eligible";

    }

    if (income < 25000) {

        return "Rejected - Low Income";

    }

    if (score >= 750) {

        return "Loan Approved";

    }

    if (score >= 650) {

        return "Approval Pending";

    }

    return "Rejected";

}


// Remarks

function showRemarks(age, income, score) {

    let remarks = [];

    if (age >= 21 && age <= 60)
        remarks.push("✓ Age Criteria Passed");
    else
        remarks.push("✗ Age Criteria Failed");

    if (income >= 25000)
        remarks.push("✓ Income Verified");
    else
        remarks.push("✗ Income Below Requirement");

    if (score >= 750)
        remarks.push("✓ Excellent Credit Score");
    else if (score >= 650)
        remarks.push("✓ Average Credit Score");
    else
        remarks.push("✗ Poor Credit Score");

    let output = "";

    for (let i = 0; i < remarks.length; i++) {

        output += remarks[i] + "<br>";

    }

    document.getElementById("remarks").innerHTML =
        output;

}


// Main Function

function checkDecision() {

    let age =
        Number(document.getElementById("age").value);

    let income =
        Number(document.getElementById("income").value);

    let score =
        Number(document.getElementById("score").value);

    let employment =
        document.getElementById("employment").value;


    if (

        age <= 0 ||

        income <= 0 ||

        score <= 0 ||

        employment === ""

    ) {

        document.getElementById("result").innerHTML =
            "<h3>Please fill all fields.</h3>";

        document.getElementById("remarks").innerHTML =
            "";

        return;

    }


    let category =
        getEmploymentCategory(employment);

    let status =
        evaluateLoan(age, income, score);


    // Update localStorage

    let applicant =
        JSON.parse(localStorage.getItem("loanApplicant"));

    applicant.age = age;
    applicant.income = income;
    applicant.creditScore = score;
    applicant.score = score;
    applicant.employment = employment;
    applicant.category = category;
    applicant.status = status;

    localStorage.setItem(
        "loanApplicant",
        JSON.stringify(applicant)
    );


    // Display Result

    document.getElementById("result").innerHTML =

        "<h3>" + status + "</h3>" +

        "<p><strong>Risk Level :</strong> "

        + category +

        "</p>";


    showRemarks(age, income, score);

}