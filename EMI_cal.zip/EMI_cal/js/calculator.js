//==========================================================
// calculator.js (Part 1)
// Loan Eligibility & EMI Checker
// Person 1 - Input Module
// Person 2 - Display Applicant
//==========================================================

// Preview Applicant Details
function previewData() {

    let name = document.getElementById("name").value.trim();
    let age = Number(document.getElementById("age").value);
    let income = Number(document.getElementById("income").value);
    let loanAmount = Number(document.getElementById("loanAmount").value);
    let loanType = document.getElementById("loanType").value;
    let employment = document.getElementById("employment").value;
    let creditScore = document.getElementById("creditScore").value;
    let tenure = document.getElementById("tenure").value;

    if (
        name === "" ||
        employment === "" ||
        loanType === "" ||
        age < 21 ||
        income <= 0 ||
        loanAmount <= 0 ||
        creditScore === ""
    ) {
        alert("Please enter valid applicant details.");
        return;
    }

    document.getElementById("previewSection").innerHTML = `
        <h3>Applicant Details</h3>
        <p><b>Name:</b> ${name}</p>
        <p><b>Age:</b> ${age}</p>
        <p><b>Employment:</b> ${employment}</p>
        <p><b>Loan Type:</b> ${loanType}</p>
        <p><b>Monthly Income:</b> ₹${income}</p>
        <p><b>Loan Amount:</b> ₹${loanAmount}</p>
        <p><b>Credit Score:</b> ${creditScore}</p>
        <p><b>Loan Tenure:</b> ${tenure} Years</p>
    `;
}

// Save Applicant Data
function saveData() {

    let applicant = {

        name: document.getElementById("name").value,
        applicantId: document.getElementById("applicantId").value,
        age: Number(document.getElementById("age").value),
        gender: document.getElementById("gender").value,
        employment: document.getElementById("employment").value,
        loanType: document.getElementById("loanType").value,
        income: Number(document.getElementById("income").value),
        existingEmi: Number(document.getElementById("existingEmi").value),
        loanAmount: Number(document.getElementById("loanAmount").value),
        tenure: Number(document.getElementById("tenure").value),
        creditScore: Number(document.getElementById("creditScore").value),
        score: Number(document.getElementById("creditScore").value),
        existingCustomer:
            document.getElementById("existingCustomer").value === "true"

    };

    if (
        applicant.name === "" ||
        applicant.loanType === "" ||
        applicant.employment === "" ||
        applicant.income <= 0 ||
        applicant.loanAmount <= 0
    ) {
        alert("Please fill all required fields.");
        return;
    }

    localStorage.setItem(
        "loanApplicant",
        JSON.stringify(applicant)
    );

    alert("Applicant data saved successfully.");

    window.location.href = "calculator.html";
}

// Display Applicant Details
function displayApplicant() {

    let applicant =
        JSON.parse(localStorage.getItem("loanApplicant"));

    if (!applicant) return;

    const details =
        document.getElementById("applicantDetails");

    if (!details) return;

    details.innerHTML = `
        <p><b>Name:</b> ${applicant.name}</p>
        <p><b>Applicant ID:</b> ${applicant.applicantId}</p>
        <p><b>Age:</b> ${applicant.age}</p>
        <p><b>Employment:</b> ${applicant.employment}</p>
        <p><b>Loan Type:</b> ${applicant.loanType}</p>
        <p><b>Monthly Income:</b> ₹${applicant.income.toLocaleString()}</p>
        <p><b>Loan Amount:</b> ₹${applicant.loanAmount.toLocaleString()}</p>
        <p><b>Loan Tenure:</b> ${applicant.tenure} Years</p>
        <p><b>Credit Score:</b> ${applicant.creditScore}</p>
    `;
}

if (document.getElementById("applicantDetails")) {
    displayApplicant();
}

// Interest Rate
function getInterestRate(type) {

    switch (type) {

        case "Home Loan":
            return 8.5;

        case "Car Loan":
            return 9;

        case "Education Loan":
            return 7.5;

        case "Personal Loan":
            return 12;

        default:
            return 10;

    }

}

// Part 2 starts with calculateLoan() and clearResults().

//==========================================================
// PERSON 2
// EMI CALCULATION MODULE
//==========================================================

// Calculate Loan EMI

function calculateLoan() {

    let applicant =
        JSON.parse(localStorage.getItem("loanApplicant"));

    if (!applicant) {

        alert("No Applicant Data Found");

        return;

    }

    // Interest Rate

    let interest =
        getInterestRate(applicant.loanType);

    // Loan Details

    let loanAmount =
        applicant.loanAmount;

    let months =
        applicant.tenure * 12;

    let monthlyRate =
        interest / 12 / 100;

    // EMI Formula

    let emi =
        (loanAmount * monthlyRate *
        Math.pow(1 + monthlyRate, months))
        /
        (Math.pow(1 + monthlyRate, months) - 1);

    // Total Payment

    let totalPayment =
        emi * months;

    // Total Interest

    let totalInterest =
        totalPayment - loanAmount;

    // Processing Fee (1%)

    let processingFee =
        loanAmount * 0.01;

    // GST (18%)

    let gst =
        processingFee * 0.18;

    // Total Charges

    let totalCharges =
        processingFee + gst;

    // Loan Eligibility

    let status = "";

    if (applicant.age < 21 || applicant.age > 60) {

        status = "Rejected";

    }
    else if (applicant.income < 25000) {

        status = "Rejected";

    }
    else if (applicant.creditScore < 700) {

        status = "Rejected";

    }
    else {

        status = "Approved";

    }

    // Save Calculated Values

    applicant.interest = interest;

    applicant.emi = emi;

    applicant.totalPayment = totalPayment;

    applicant.totalInterest = totalInterest;

    applicant.processingFee = processingFee;

    applicant.gst = gst;

    applicant.totalCharges = totalCharges;

    applicant.status = status;

    localStorage.setItem(
        "loanApplicant",
        JSON.stringify(applicant)
    );

    // Display Results

    document.getElementById("interestRate").innerHTML =
        interest.toFixed(2) + " %";

    document.getElementById("emi").innerHTML =
        "₹ " + emi.toFixed(2);

    document.getElementById("totalInterest").innerHTML =
        "₹ " + totalInterest.toFixed(2);

    document.getElementById("totalPayment").innerHTML =
        "₹ " + totalPayment.toFixed(2);

    // Display only if IDs exist

    if (document.getElementById("processingFee")) {

        document.getElementById("processingFee").innerHTML =
            "₹ " + processingFee.toFixed(2);

    }

    if (document.getElementById("gst")) {

        document.getElementById("gst").innerHTML =
            "₹ " + gst.toFixed(2);

    }

    if (document.getElementById("charges")) {

        document.getElementById("charges").innerHTML =
            "₹ " + totalCharges.toFixed(2);

    }

    // Status

    let statusElement =
        document.getElementById("status");

    statusElement.innerHTML = status;

    if (status === "Approved") {

        statusElement.className = "success";

    }
    else {

        statusElement.className = "error";

    }

    // Array Example

    let loanSummary = [

        interest,

        emi,

        totalInterest,

        totalPayment,

        processingFee,

        gst,

        totalCharges

    ];

    // Loop Example

    console.log("Loan Summary");

    for (let i = 0; i < loanSummary.length; i++) {

        console.log(loanSummary[i]);

    }

    // var Example

    var message = "Loan Calculation Completed";

    console.log(message);

}



//==========================================================
// Clear Results
//==========================================================

function clearResults() {

    document.getElementById("interestRate").innerHTML = "-";

    document.getElementById("emi").innerHTML = "-";

    document.getElementById("totalInterest").innerHTML = "-";

    document.getElementById("totalPayment").innerHTML = "-";

    if (document.getElementById("processingFee")) {

        document.getElementById("processingFee").innerHTML = "-";

    }

    if (document.getElementById("gst")) {

        document.getElementById("gst").innerHTML = "-";

    }

    if (document.getElementById("charges")) {

        document.getElementById("charges").innerHTML = "-";

    }

    document.getElementById("status").innerHTML = "-";

}