package com.wallet.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.wallet.app.model.PhysicalGoldTransactions;
import com.wallet.app.model.PhysicalGoldTransactions;
import com.wallet.app.model.Users;

import java.util.List;

public interface PhysicalGoldTransactionRepository extends JpaRepository<PhysicalGoldTransactions, Long> {
//    List<PhysicalGoldTransaction> findByBranchBranchIdIn(List<Long> branchIds);
    List<PhysicalGoldTransactions> findByUser(Users user);
    List<PhysicalGoldTransactions> findByBranchBranchIdIn(List<Long> branchIds);
    
}